<?php
session_destroy();
?>